

// Define pins numbers for RGB LED and Power LED
#define NUM_LEDS   4
#define RED_PIN   22
#define GREEN_PIN 23
#define BLUE_PIN  24     
#define PWR_PIN   25
int LEDPins[4] = {RED_PIN, GREEN_PIN, BLUE_PIN, PWR_PIN};

// Class recognition threshold
const double RECOGNITION_THRESHOLD=0.90;

#define NOISE_CLASS 1

int recognizedClass=-1, previousClass=-1;
